#include <iostream>
#include <iomanip>
#include <vector>
#include <fstream>
#include <sstream>
#include <unistd.h>
#include <string>
#include <string.h>
#include <stdlib.h>
#include <zlib.h>
#include <zconf.h>
#include <time.h>
#include <stdio.h>
#include <map>
#include "GTF.h"

using namespace std;
#define BUFFER 2048

void PrintUsage(){
  cerr << "program <genome.fa> <annotation.gtf> <mapping_1.sam> <mapping_2.sam> ..." << endl;
}
void initMapper(map<string, vector<int> > &mapper,string genomeFile);
int readSAM(map<string,vector<int> > &mapper, string alignFile);
void checkCDSCoverage(map<string,vector<int> > &mapper, GTF &gtf);
void checkGeneCoverage(map<string,vector<int> > &mapper, GTF &gtf);
void checkGeneEvenness(map<string,vector<int> > &mapper, GTF &gtf);
void checkCDSEvenness(map<string,vector<int> > &mapper, GTF &gtf);
void PrintChrSize(map<string,vector<int> > mapper);

int main(int argc, char* argv[]){
  string of = "output";
  if(argc<4){
    PrintUsage();
    exit(-1);
  }
  string genomeFile=argv[1];
  string annotationFile=argv[2];
  vector<string> sam;
  for(int i=3;i<argc;i++){
    sam.push_back(argv[i]);
  }
  GTF gtf;
  map<string,vector<int> > mapper;

  //Reading annotation
  clock_t start=clock();
  cerr <<"Read annotation file: "<<annotationFile<<" ......"<<endl;
  gtf.ReadGTF(annotationFile);
  clock_t end=clock();
  double duration= (double)(end-start)/CLOCKS_PER_SEC;
  cerr << "Transcript number: " << gtf.size <<endl;
  cerr << "Time used:" << duration << "s" <<endl;
  start=clock();
  cerr <<"Check chromosomes lengths"<<" ......"<<endl;
  initMapper(mapper,genomeFile);
  //  PrintChrSize(mapper);
  end=clock();
  duration= (double)(end-start)/CLOCKS_PER_SEC-duration;
  cerr << "Time used:" << duration << "s" <<endl;

  //reading SAM
  cerr <<"Read mapping file:"<<endl;
  start=clock();
  vector<string>::iterator samIter=sam.begin();
  int num=0;
  while(samIter!=sam.end()){
    cerr <<"\t"<<*samIter<<endl;
    num+=readSAM(mapper,*samIter);
    ++samIter;
  }
  end=clock();
  duration= (double)(end-start)/CLOCKS_PER_SEC-duration;
  cerr << "Aligned read number: " << num <<endl;
  cerr << "Time used:" << duration << "s" <<endl;

  //Check coverage
  cerr <<"Calculate coverage and evenness" <<" ......"<<endl;
  checkCDSCoverage(mapper,gtf);
  checkGeneCoverage(mapper,gtf);
  checkCDSEvenness(mapper,gtf);
  checkGeneEvenness(mapper,gtf);

  end=clock();
  duration= (double)(end-start)/CLOCKS_PER_SEC-duration;
  cerr << "Time used:" << duration << "s" <<endl;

  //Output coverage
 
  cout<<"#name\tchr\tbegin\tend\tgene_coverage\tgene_depth\tgene_evenness\tcds_coverage\tcds_depth\tcds_evenness"<<endl;

  vector<GeneStructure>::iterator oiter=gtf.GeneStructureSequence.begin();
  while(oiter!=gtf.GeneStructureSequence.end()){
    cout<<oiter->name <<"\t"<<oiter->chr<<"\t"<<oiter->begin<<"\t"<<oiter->end;
    cout<< setprecision(4)
	<<"\t"<< oiter->geneCov <<"\t"<< oiter->geneDep <<"\t"<< oiter->geneEven 
	<<"\t"<< oiter->cdsCov  <<"\t"<< oiter->cdsDep  <<"\t"<< oiter->cdsEven 
	<<endl;
    ++oiter;
  }

  duration= (double)(end-start)/CLOCKS_PER_SEC;
  cerr << "Total time used:" << duration << "s" <<endl; 
  
  return 0;
}

void checkCDSCoverage(map<string,vector<int> > &mapper, GTF &gtf){
  vector<GeneStructure>::iterator giter=gtf.GeneStructureSequence.begin();
  while(giter!=gtf.GeneStructureSequence.end()){
    int tlength=0;
    int slength=0;
    int alength=0;
    vector<GeneItem>::iterator iiter=giter->itemseq.begin();
    while(iiter!=giter->itemseq.end()){
      tlength+=(iiter->end-iiter->begin+1);
      for(int i=iiter->begin;i<=iiter->end;++i){
	alength+=mapper[iiter->chr][i-1];
	if(mapper[iiter->chr][i-1]>0){
	  slength++;
	}
      }
      ++iiter;
    }
    giter->cdsDep=(double)alength/(double)tlength;
    giter->cdsCov=(double)slength/(double)tlength;
    ++giter;
  }
}

void checkCDSEvenness(map<string,vector<int> > &mapper, GTF &gtf){
  vector<GeneStructure>::iterator giter=gtf.GeneStructureSequence.begin();
  while(giter!=gtf.GeneStructureSequence.end()){
    int tlength=0;
    vector<GeneItem>::iterator iiter=giter->itemseq.begin();
    int even=0;
    while(iiter!=giter->itemseq.end()){
      tlength+=(iiter->end-iiter->begin);
      for(int i=iiter->begin+1;i<=iiter->end;i++){
	if( (mapper[iiter->chr][i-1]>0 && mapper[iiter->chr][i-2]>0)
	    ||  (mapper[iiter->chr][i-1]==0 && mapper[iiter->chr][i-2]==0)){
	  even++;
	}
      }
      ++iiter;
    }
    giter->cdsEven=(double)even/(double)tlength;
    ++giter;
  }
}


void checkGeneEvenness(map<string,vector<int> > &mapper, GTF &gtf){
  vector<GeneStructure>::iterator giter=gtf.GeneStructureSequence.begin();
  while(giter!=gtf.GeneStructureSequence.end()){
    int tlength=giter->end - giter->begin;
    int even=0;
    for(int i=giter->begin+1;i<=giter->end;i++){
      if( (mapper[giter->chr][i-1]>0 && mapper[giter->chr][i-2]>0)
	  ||  (mapper[giter->chr][i-1]==0 && mapper[giter->chr][i-2]==0)){
	even++;
      }
    }
    giter->geneEven=(double)even/(double)tlength;
    ++giter;
  }
}

void checkGeneCoverage(map<string,vector<int> > &mapper, GTF &gtf){
  vector<GeneStructure>::iterator giter=gtf.GeneStructureSequence.begin();
  while(giter!=gtf.GeneStructureSequence.end()){
    int tlength=giter->end - giter->begin + 1;
    int slength=0;
    int alength=0;
    for(int i=giter->begin;i<=giter->end;i++){
      //      if(i-1>=mapper[giter->chr].size()){
      //	cerr << i <<"\t**"<<mapper[giter->chr].size()<<endl;
      //	exit(-1);
      //      }  
    alength+=mapper[giter->chr][i-1];
      if(mapper[giter->chr][i-1]>0){
	slength++;
	alength+=mapper[giter->chr][i-1];
      }
    }
    giter->geneDep=(double)alength/(double)tlength;
    giter->geneCov=(double)slength/(double)tlength;
    ++giter;
  }
}


int readSAM(map<string,vector<int> > &mapper, string alignFile){
  string line;
  string chr;
  string cigar;
  int start;
  int n=0;
  string tmp;
  ifstream alignStream(alignFile.c_str());
  if(!alignStream){
    cerr << "Unable to open align file: "
	 << alignFile << endl;
    exit(-1);
  }
  
  while(getline(alignStream, line)){
    n++;
    istringstream iline(line);
    iline >> tmp;
    iline >> tmp;
    iline >> chr;
    iline >> start;
    iline >> tmp;
    iline >> cigar;
    string integer="";
    int inte_n;
    for(int i=0;i<cigar.size();i++){
      if(isdigit(cigar[i])){
	integer+=cigar[i];
      }
      else if(cigar[i]=='M'){
	istringstream s2i(integer);
	s2i >> inte_n;
	for(int j=0;j<inte_n;j++){
	  mapper[chr][start-1]++;
	  start++;
	}
	integer="";
      }
      else if(cigar[i]=='N'){
	istringstream s2i(integer);
	s2i >> inte_n;
	start+=inte_n;;
	integer="";
      }
      else if(cigar[i]=='I'){
	integer="";
      }
      else if(cigar[i]=='D'){
	istringstream s2i(integer);
	s2i >> inte_n;
	for(int j=0;j<inte_n;j++){
	  mapper[chr][start-1]++;
	  start++;
	}
	integer="";
      }	 
      else{
	integer="";
	continue;
      }
    }
  }
  alignStream.close();
  return n;
}


void initMapper(map<string,vector<int> > &mapper,string genomeFile){
  ifstream genomeStream;
  if(genomeFile.substr(genomeFile.size()-3)==".gz"){
    genomeFile = "zcat " + genomeFile +"|";
  }
  genomeStream.open(genomeFile.c_str());
  if(!genomeStream){
    cerr << "Unable to open reference genome file: "
         << genomeFile << endl;
    exit(-1);
  }
  string seq;
  string line;
  string chr="";
  while(getline(genomeStream, line)){
    if(line[0]=='>'){
      if(chr!=""){
	vector<int> tmp(seq.size(),0);
	mapper[chr]=tmp;
      }
      chr=line.substr(1,line.size()-1);
      seq="";
    }
    else{
      seq+=line;
    }
  }
  genomeStream.close();
  vector<int> tmp(seq.size(),0);
  mapper[chr]=tmp;
}

void PrintChrSize(map<string,vector<int> > mapper){
  map<string,vector<int> >::iterator iter=mapper.begin();
  while(iter!=mapper.end()){
    cerr<<iter->first << "\t" << iter->second.size()<<endl;
    iter++;
  }
}
