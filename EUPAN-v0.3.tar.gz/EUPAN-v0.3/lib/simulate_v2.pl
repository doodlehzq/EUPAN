#!/usr/bin/perl 
use strict;
use warnings;

my $usage="$0 <Exist.txt> <iteration times> >sim_out.txt 
";

die $usage if @ARGV!=2;

my ($gEfile,$number)=@ARGV;

##### read geneExist ########

open(EX,$gEfile);
my $i=0;
my @riceline;
my @geneName;
my @geneExt;
while(<EX>){
    $i++;
    chomp;
    if($i==1){
	@riceline=split /\t/,$_;
	shift @riceline;
	next;
    }
    my @t=split /\t/,$_;
    my $item=shift @t;
    my $u=0;
#    if(defined $knownCore{$item}){ 
#	foreach my $kk (@t){
#	    $kk=1;
#	}
#    }
   foreach my $kk (@t){
	$u+=$kk;
    }
    if($u==0){
	next;
    }
    push @geneName, $item;
    push @geneExt, \@t;
}
close EX;
###### simulation #######
print "Time\tCore\tPan\n";
foreach (1..$number){
    my @r=frand(scalar(@riceline));
    my (@core,@pan);
    my ($c,$p)=(0,0);
#init
    for(my $i=0;$i<@geneExt;$i++){
	push @core,$geneExt[$i]->[$r[0]];
    }
    @pan=@core;
    for(my $i=0;$i<@pan;$i++){
	$c+=$core[$i];
    }
    $p=$c;
    print "1\t$p\t$c\n";
    for(my $i=1;$i<@r;$i++){
	for(my $j=0;$j<@geneExt;$j++){
	    if($core[$j]==1 && $geneExt[$j]->[$r[$i]]!=1){
		$core[$j]=0;
		$c--;
	    }
	    if($pan[$j]!=1 && $geneExt[$j]->[$r[$i]]==1){
		$pan[$j]=1;
		$p++;
	    }
	}
	print $i+1,"\t$c\t$p\n";
    }
}


sub frand{
    my @r;
    my %h;
    foreach (1..$_[0]){
	$h{$_-1}=1;
    }
    my @t=keys(%h);
    while(@t>0){
	my $i=int(rand(scalar(@t)));
	push @r,$t[$i];
	delete($h{$t[$i]});
	@t=keys(%h);
    }
    return @r;
}

